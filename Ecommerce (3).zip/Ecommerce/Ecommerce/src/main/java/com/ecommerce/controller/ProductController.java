package com.ecommerce.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ecommerce.entity.Product;
import com.ecommerce.service.ProductServiceImpl;
@RequestMapping("/ecommerce")
@RestController
public class ProductController {
@Autowired
ProductServiceImpl productServiceImpl;
@PostMapping("/add")
public ResponseEntity<String> addProduct(@RequestBody Product product){
	productServiceImpl.addProduct(product);
	return new ResponseEntity<String>("PRODUCT ADDED SUCUESSFULLY ",HttpStatus.ACCEPTED);
}
@GetMapping("/all")
public List<Product> getAllProduct(){
	return productServiceImpl.getAllProduct();
}
@GetMapping("/{id}")
public Product getById(@PathVariable int id){
	return productServiceImpl.getById(id);
}
@PutMapping("/update/{id}")
public ResponseEntity<String> updateProduct(@PathVariable int id, @RequestBody Product product){
	productServiceImpl.updateProduct(id, product);
	return new ResponseEntity<String>("Product " +id +" updated",HttpStatus.ACCEPTED);
}
@DeleteMapping("/delete/{id}")
public ResponseEntity<String> deleteProduct(@PathVariable int id){
	productServiceImpl.deleteProduct(id);
	return new ResponseEntity<String>("this "+id+" deleted sucuessfully",HttpStatus.ACCEPTED);
}
}
