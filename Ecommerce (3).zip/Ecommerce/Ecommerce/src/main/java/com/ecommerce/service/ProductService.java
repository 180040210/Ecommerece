package com.ecommerce.service;

import java.util.List;

import com.ecommerce.entity.Product;

public interface ProductService {
	
		public Product addProduct(Product product);
		public List<Product> getAllProduct();
		public void updateProduct(int id,Product product);
		public void deleteProduct(int id);
		public Product getById(int id);
}
