package com.ecommerce.exception;

public class CustomExceptoin extends RuntimeException {

	public CustomExceptoin(String message) {
		super(message);
	}
	

}
