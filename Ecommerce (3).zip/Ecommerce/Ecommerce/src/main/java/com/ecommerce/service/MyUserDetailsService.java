package com.ecommerce.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.ecommerce.entity.UserPrinciples;
import com.ecommerce.entity.Users;
import com.ecommerce.repository.UserRepo;

@Service
public class MyUserDetailsService implements UserDetailsService {
	@Autowired
	UserRepo userRepo;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		Users users = userRepo.findByUserName(username);
		if(users==null) {
			System.out.println("NO USER FOUND by");
			throw new UsernameNotFoundException("User Not Found");
		}
		
		return new UserPrinciples(users);
	}

}
