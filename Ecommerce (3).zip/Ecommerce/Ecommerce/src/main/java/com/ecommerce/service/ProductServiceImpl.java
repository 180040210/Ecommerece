package com.ecommerce.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ecommerce.entity.Product;
import com.ecommerce.exception.CustomExceptoin;
import com.ecommerce.exception.ProductNotFoundException;
import com.ecommerce.repository.ProductRepo;
@Service
public class ProductServiceImpl implements ProductService{
	@Autowired
	ProductRepo productRepo;

	@Override
	public Product addProduct(Product product) throws CustomExceptoin{
		
		return productRepo.save(product);
	}

	@Override
	public List<Product> getAllProduct()  {
		return productRepo.findAll();
	}

	@Override
	public void updateProduct(int id, Product product) throws ProductNotFoundException {
		// TODO Auto-generated method stub
		
		Optional<Product> existingProduct = productRepo.findById(id);
		if(existingProduct.isPresent()) {
			Product updateProduct = existingProduct.get();
			updateProduct.setAvailability(product.isAvailability());
			updateProduct.setBrand(product.getBrand());
			updateProduct.setCost(product.getCost());
			updateProduct.setDiscription(product.getDiscription());
			updateProduct.setName(product.getName());
			productRepo.save(updateProduct);
		}
		else {
			throw new ProductNotFoundException("Product Id "+id+" Not Found");
		}
		
	}

	@Override
	public void deleteProduct(int id) throws ProductNotFoundException {
		Optional<Product> product = productRepo.findById(id);
		if(product.isEmpty()) {
			throw new ProductNotFoundException("Product Id "+id+" Not Found");
		}
		 productRepo.deleteById(id);
	}

	@SuppressWarnings("deprecation")
	@Override
	public Product getById(int id) throws ProductNotFoundException{
		// TODO Auto-generated method stub
		Product product = productRepo.findById(id).orElseThrow(()->  new ProductNotFoundException ("Product Id "+id+" Not Found"));
		
		return product;
	}

}
